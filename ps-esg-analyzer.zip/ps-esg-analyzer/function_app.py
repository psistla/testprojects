import azure.functions as func
import logging
import json
import uuid
from datetime import datetime
from typing import Dict, List, Any
import pandas as pd
from io import BytesIO
from azure.storage.blob import BlobServiceClient
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
import asyncio
from concurrent.futures import ThreadPoolExecutor
import os

app = func.FunctionApp()

# ESG Metrics Template
ESG_METRICS_TEMPLATE = {
    "Environmental": {
        "energy": ["energy consumption", "energy usage", "electricity", "power consumption", "kwh", "mwh"],
        "emissions": ["ghg emissions", "carbon emissions", "co2", "scope 1", "scope 2", "scope 3", "carbon footprint"],
        "water": ["water consumption", "water usage", "water withdrawal", "water discharge", "cubic meters"],
        "waste": ["waste generated", "waste recycled", "waste disposal", "hazardous waste", "recycling rate"],
        "biodiversity": ["biodiversity impact", "land use", "habitat protection", "species conservation"]
    },
    "Social": {
        "employees": ["employee count", "headcount", "workforce size", "fte", "full time employees"],
        "diversity": ["gender diversity", "ethnic diversity", "women employees", "diversity ratio", "inclusion"],
        "safety": ["injury rate", "accident rate", "ltir", "trir", "safety incidents", "fatalities"],
        "training": ["training hours", "employee development", "skill development", "education programs"],
        "community": ["community investment", "social impact", "charitable donations", "volunteering hours"]
    },
    "Governance": {
        "board": ["board diversity", "board independence", "board size", "independent directors"],
        "ethics": ["code of conduct", "ethics violations", "compliance breaches", "whistleblower reports"],
        "transparency": ["disclosure score", "reporting quality", "audit findings", "transparency index"],
        "risk": ["risk assessment", "risk management", "enterprise risk", "risk mitigation"],
        "cybersecurity": ["cyber incidents", "data breaches", "security violations", "information security"]
    }
}

class ESGProcessor:
    def __init__(self):
        # Azure configurations
        self.storage_connection_string = os.environ["AzureWebJobsStorage"]
        self.doc_intelligence_endpoint = os.environ["DOCUMENT_INTELLIGENCE_ENDPOINT"]
        self.doc_intelligence_key = os.environ["DOCUMENT_INTELLIGENCE_KEY"]
        self.output_container = os.environ.get("OUTPUT_CONTAINER", "output-files")
        
        # Initialize clients
        self.blob_service_client = BlobServiceClient.from_connection_string(self.storage_connection_string)
        self.doc_intelligence_client = DocumentIntelligenceClient(
            endpoint=self.doc_intelligence_endpoint,
            credential=AzureKeyCredential(self.doc_intelligence_key)
        )
        
    async def process_excel_file(self, blob_data: bytes, filename: str) -> Dict[str, Any]:
        """Process Excel file and extract ESG metrics"""
        try:
            # Read Excel file
            excel_data = pd.read_excel(BytesIO(blob_data), sheet_name=None)
            
            # Process with Document Intelligence for enhanced extraction
            poller = self.doc_intelligence_client.begin_analyze_document(
                "prebuilt-layout",
                document=blob_data,
                content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
            result = poller.result()
            
            # Extract metrics based on template
            extracted_metrics = self._extract_esg_metrics(excel_data, result)
            
            return {
                "status": "success",
                "filename": filename,
                "processed_at": datetime.utcnow().isoformat(),
                "metrics": extracted_metrics,
                "metadata": {
                    "sheets_processed": len(excel_data),
                    "total_cells_analyzed": sum(df.size for df in excel_data.values())
                }
            }
            
        except Exception as e:
            logging.error(f"Error processing file {filename}: {str(e)}")
            return {
                "status": "error",
                "filename": filename,
                "error": str(e),
                "processed_at": datetime.utcnow().isoformat()
            }
    
    def _extract_esg_metrics(self, excel_data: Dict[str, pd.DataFrame], 
                           doc_result: Any) -> Dict[str, Dict[str, Any]]:
        """Extract ESG metrics based on template"""
        extracted = {"Environmental": {}, "Social": {}, "Governance": {}}
        
        for sheet_name, df in excel_data.items():
            # Convert dataframe to lowercase for matching
            df_lower = df.astype(str).apply(lambda x: x.str.lower())
            
            for category, subcategories in ESG_METRICS_TEMPLATE.items():
                for metric_type, keywords in subcategories.items():
                    # Search for keywords in the dataframe
                    matches = self._find_metric_values(df, df_lower, keywords)
                    if matches:
                        if metric_type not in extracted[category]:
                            extracted[category][metric_type] = []
                        extracted[category][metric_type].extend(matches)
        
        # Enhance with Document Intelligence insights
        if doc_result.tables:
            self._enhance_with_doc_intelligence(extracted, doc_result)
        
        return extracted
    
    def _find_metric_values(self, df: pd.DataFrame, df_lower: pd.DataFrame, 
                          keywords: List[str]) -> List[Dict[str, Any]]:
        """Find metric values based on keywords"""
        matches = []
        
        for keyword in keywords:
            # Search in all cells
            mask = df_lower.apply(lambda x: x.astype(str).str.contains(keyword, na=False))
            locations = list(zip(*mask.values.nonzero()))
            
            for row, col in locations:
                # Look for numeric values in adjacent cells
                value = self._extract_numeric_value(df, row, col)
                if value is not None:
                    matches.append({
                        "keyword": keyword,
                        "value": value,
                        "location": f"Row {row+1}, Column {col+1}",
                        "context": str(df.iloc[row, col])
                    })
        
        return matches
    
    def _extract_numeric_value(self, df: pd.DataFrame, row: int, col: int) -> Any:
        """Extract numeric value from cell or adjacent cells"""
        # Check current cell
        try:
            value = pd.to_numeric(df.iloc[row, col], errors='coerce')
            if pd.notna(value):
                return float(value)
        except:
            pass
        
        # Check adjacent cells (right and below)
        for dr, dc in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
            try:
                if 0 <= row + dr < len(df) and 0 <= col + dc < len(df.columns):
                    value = pd.to_numeric(df.iloc[row + dr, col + dc], errors='coerce')
                    if pd.notna(value):
                        return float(value)
            except:
                pass
        
        return None
    
    def _enhance_with_doc_intelligence(self, extracted: Dict, doc_result: Any) -> None:
        """Enhance extraction with Document Intelligence results"""
        for table in doc_result.tables:
            for cell in table.cells:
                content_lower = cell.content.lower()
                for category, subcategories in ESG_METRICS_TEMPLATE.items():
                    for metric_type, keywords in subcategories.items():
                        if any(keyword in content_lower for keyword in keywords):
                            # Found a match, try to extract value
                            if metric_type not in extracted[category]:
                                extracted[category][metric_type] = []
                            extracted[category][metric_type].append({
                                "source": "document_intelligence",
                                "content": cell.content,
                                "confidence": getattr(cell, 'confidence', None)
                            })

@app.blob_trigger(arg_name="inputblob", path="input-files/{name}",
                  connection="AzureWebJobsStorage")
async def process_esg_metrics(inputblob: func.InputStream, context: func.Context):
    """Azure Function triggered by blob upload"""
    logging.info(f"Processing blob: {inputblob.name}, Size: {inputblob.length} bytes")
    
    processor = ESGProcessor()
    
    # Generate unique identifier
    unique_id = str(uuid.uuid4())[:8]
    original_filename = inputblob.name.split('/')[-1]
    
    # Read blob data
    blob_data = inputblob.read()
    
    # Process file
    result = await processor.process_excel_file(blob_data, original_filename)
    result["unique_id"] = unique_id
    
    # Generate output filename
    output_filename = f"processed_{unique_id}_{original_filename.replace('.xlsx', '.json').replace('.xls', '.json')}"
    
    # Upload result to output container
    output_container_client = processor.blob_service_client.get_container_client(processor.output_container)
    output_blob_client = output_container_client.get_blob_client(output_filename)
    
    output_blob_client.upload_blob(
        json.dumps(result, indent=2),
        overwrite=True,
        content_settings=func.ContentSettings(content_type="application/json")
    )
    
    logging.info(f"Successfully processed and uploaded: {output_filename}")

# Batch processing endpoint
@app.route(route="batch-process", auth_level=func.AuthLevel.FUNCTION)
async def batch_process_endpoint(req: func.HttpRequest) -> func.HttpResponse:
    """HTTP endpoint for batch processing multiple files"""
    logging.info("Batch processing endpoint triggered")
    
    try:
        req_body = req.get_json()
        container_name = req_body.get("container", "input-files")
        file_prefix = req_body.get("prefix", "")
        max_files = req_body.get("max_files", 10)
        
        processor = ESGProcessor()
        container_client = processor.blob_service_client.get_container_client(container_name)
        
        # List blobs to process
        blobs = list(container_client.list_blobs(name_starts_with=file_prefix))[:max_files]
        
        # Process files in parallel
        results = []
        with ThreadPoolExecutor(max_workers=5) as executor:
            tasks = []
            for blob in blobs:
                blob_client = container_client.get_blob_client(blob.name)
                blob_data = blob_client.download_blob().readall()
                
                # Create async task
                loop = asyncio.get_event_loop()
                task = loop.run_in_executor(
                    executor, 
                    asyncio.run, 
                    processor.process_excel_file(blob_data, blob.name)
                )
                tasks.append(task)
            
            # Wait for all tasks to complete
            for i, task in enumerate(asyncio.as_completed(tasks)):
                result = await task
                results.append(result)
                logging.info(f"Processed {i+1}/{len(tasks)} files")
        
        return func.HttpResponse(
            json.dumps({
                "status": "success",
                "files_processed": len(results),
                "results": results
            }),
            mimetype="application/json",
            status_code=200
        )
        
    except Exception as e:
        logging.error(f"Batch processing error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"status": "error", "message": str(e)}),
            mimetype="application/json",
            status_code=500
        )